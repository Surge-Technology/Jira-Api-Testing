package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.camunda.zeebe.client.ZeebeClient;

@RestController
public class CamundaJiraController {

	@Autowired
	ZeebeClient zeebeClient;

	@GetMapping("/Create")
	public String test() {
		Map<String, String> tempMap = new HashMap<>();
		tempMap.put("jira", "create");
		zeebeClient.newCreateInstanceCommand().bpmnProcessId("Jira_Applications").latestVersion().variables(tempMap)
				.send().join();

		return "Created successfully";

	}

	@PutMapping("/Update")
	public String updateIssue(@RequestBody Map<String, Object> requestBody) {
		String issueKey = (String) requestBody.get("issueKey");
		String newSummary = (String) requestBody.get("newSummary");
		Map<String, String> updateMap = new HashMap<>();
		updateMap.put("jira", "update");
		updateMap.put("issueKey", issueKey);
		updateMap.put("newSummary", newSummary);

		System.out.println("Controller level" + issueKey);

		System.out.println("Controller Level newSummary: " + newSummary);

		zeebeClient.newCreateInstanceCommand().bpmnProcessId("Jira_Applications").latestVersion().variables(updateMap)
				.send().join();

		return "Updated successfully";

	}

	@DeleteMapping("/Delete")
	public String delete(@RequestBody Map<String, Object> requestBody) {
		String issueKey = (String) requestBody.get("issueKey");
		Map<String, String> deleteMap = new HashMap<>();
		deleteMap.put("jira", "delete");
		deleteMap.put("issueKey", issueKey);
		zeebeClient.newCreateInstanceCommand().bpmnProcessId("Jira_Applications").latestVersion().variables(deleteMap)
				.send().join();

		return "Deleted successfully";

	}

}
