package com.example.demo.util;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.springframework.stereotype.Component;

@Component
public class CommonUtil {
	
	  private static final String AUTH_HEADER = "Basic  bWFuaS5jZWcyMDE5QGdtYWlsLmNvbTpBVEFUVDN4RmZHRjAzYUI3enFzMWJscFN3ZGsxOVotc0J3Z0o5U2pIVUFMQllsMXBxTkxIN0RNS1pCZVhPVUROc2txVEJWZi1WQ1BaWWRxcmxWNzE5U3ZEWGg4U29Iby1EQUNjdWRTRC1PQlpXZFI3ZTlrNjBhT25ValZ3NmFkMHNXUDdSSlRwMW5LSk5HTEJjQ1N0ODZHV2FsU0dPODBnTzVrNV93ZUt0WXg5ejhjOUhzQUlwSFk9NkMxMjJGNjE=";
	    private static final String XSRF_TOKEN = "ATATT3xFfGF0HOlH0XJ4BjZNMlHpiNyhjYQmATfXCneoGOjCzw8ejkrgwhhbXbNUamVVh8urKtPKGPhvNPfVygHV7DJuwQjIQigVKw8tcuL2b35liI3amKVizvCU4Agclce_eA4GrFhjMAMgWy"; 

	 // private static final String XSRF_TOKEN = "ATATT3xFfGF0z89UHcbRU0xpuI0d_fshh4QzWKNp82OSrasU36gaIwJmJEGYEv4ZNlimRNKvut_bL4KtD8RaLvKgLJ4eK9Fuyy1hPww63he5dm4CAzsv0aGHMjbs4quNPaOeO1gXg8VxlqO10mgAbELe-ws5yMsa2COpSi1bJ4TrMYvvNTUuWLo=937DCEB1";
	    public static Header[] getHeaders() {
	        List<Header> headers = new ArrayList<>();
	        headers.add(new BasicHeader("Accept", "application/json"));
	        headers.add(new BasicHeader("Content-Type", "application/json"));
	        headers.add(new BasicHeader("Authorization", AUTH_HEADER));
	        headers.add(new BasicHeader("Cookie", "atlassian.xsrf.token=" + XSRF_TOKEN));

	        return headers.toArray(new Header[0]);
	    }
		

}