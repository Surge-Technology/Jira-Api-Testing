package com.example.demo.worker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Service;
import com.example.demo.util.CommonUtil;
import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.ZeebeWorker;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@SpringBootApplication
public class CamundaJiraCreateIssueWorker {

	@Autowired
	ZeebeClient zeebeClient;

	@Autowired
	CommonUtil commonUtil;

	@Value("${jira.create_url}")
	private String JIRA_CREATE_URL;

	@ZeebeWorker(name = "Create", type = "Create")
	public void createIssue(final JobClient client, final ActivatedJob job) throws Exception {
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			HttpPost httpPost = new HttpPost(JIRA_CREATE_URL);

			Header[] headers = commonUtil.getHeaders();
			httpPost.setHeaders(headers);

			String jsonPayload = constructIssuePayload();

			httpPost.setEntity(new StringEntity(jsonPayload));

			HttpResponse response = httpClient.execute(httpPost);

			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == 201) {
				System.out.println("Issue created successfully!");
			} else {
				System.out.println("Failed to create issue. Status code: " + statusCode);
			}

		} catch (Exception e) {
			e.getMessage();
		}
		zeebeClient.newCompleteCommand(job.getKey()).variables("").send().join();

	}

	private String constructIssuePayload() {
		return "{" + "\"fields\": {" + "\"description\": {" + "\"content\": [{" + "\"content\": [{"
				+ "\"text\": \"java api testing in project- from camunda\"," + "\"type\": \"text\"" + "}],"
				+ "\"type\": \"paragraph\"" + "}]" + ",\"type\": \"doc\"," + "\"version\": 1" + "},"
				+ "\"issuetype\": {\"id\": \"10001\"}," + "\"project\": {\"id\": \"10000\"},"
				+ "\"reporter\": {\"id\": \"712020:8674ae86-69cb-4a3f-ad4d-8f6be53683bf\"},"
				+ "\"summary\": \"Jira api testing - issue summary\"" + "}," + "\"update\": {}" + "}";
	}

}
