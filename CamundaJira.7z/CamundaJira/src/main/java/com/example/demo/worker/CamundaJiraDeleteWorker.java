package com.example.demo.worker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.demo.util.CommonUtil;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.ZeebeWorker;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import java.util.Map;

@SpringBootApplication
public class CamundaJiraDeleteWorker {

	@Autowired
	CommonUtil commonUtil;

	@Value("${jira.delete_url}")
	private String JIRA_DELETE_URL;

	@ZeebeWorker(type = "Delete")
	public void deleteIssue(final JobClient client, final ActivatedJob job) {
		Map<String, Object> variables = job.getVariablesAsMap();
		String issueKey = (String) variables.get("issueKey");

		if (issueKey == null || issueKey.isEmpty()) {
			System.out.println("Issue key is missing. Cannot delete.");
			failJob(client, job, "Issue key is required for deleting an issue");
			return;
		}

		String deleteUrl = JIRA_DELETE_URL + "/" + issueKey;
		
		System.out.println("Final DELETE URL: " + deleteUrl);

		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			HttpDelete httpDelete = new HttpDelete(deleteUrl);
			httpDelete.setHeaders(commonUtil.getHeaders());

			HttpResponse response = httpClient.execute(httpDelete);
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 204) {
				System.out.println("deleted successfully!");
				completeJob(client, job);
			} else {
				System.out.println("Failed to delete issue. Status code: " + statusCode);
				failJob(client, job, "Jira delete failed with status code: " + statusCode);
			}
		} catch (Exception e) {
			System.out.println("Error deleting Jira issue: " + e.getMessage());
			failJob(client, job, "Exception: " + e.getMessage());
		}
	}

	private void completeJob(JobClient client, ActivatedJob job) {
		try {
			client.newCompleteCommand(job.getKey()).send().join();
		} catch (Exception e) {
			System.out.println("Error completing job: " + e.getMessage());
		}
	}

	private void failJob(JobClient client, ActivatedJob job, String errorMessage) {
		try {
			client.newFailCommand(job.getKey()).retries(2).errorMessage(errorMessage).send().join();
		} catch (Exception e) {
			System.out.println("Error failing job: " + e.getMessage());
		}
	}
}
