package com.example.demo.worker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Service;
import com.example.demo.util.CommonUtil;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.ZeebeWorker;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.entity.StringEntity;
import org.apache.http.HttpResponse;
import org.springframework.beans.factory.annotation.Value;
import java.util.Map;

@SpringBootApplication
public class CamundaJiraUpdateWorker {

    @Autowired
    CommonUtil commonUtil;

    @Value("${jira.update_url}")
    private String jiraUpdateUrl;

    @ZeebeWorker(type = "Update")
    public void updateIssue(JobClient client, ActivatedJob job) {
        Map<String, Object> variables = job.getVariablesAsMap();
        System.out.println("Worker Variables: " + variables);

        String issueKey = (String) variables.get("issueKey");
        String newSummary = (String) variables.get("newSummary");

        if (issueKey == null || newSummary == null) {
            failJob(client, job, "Issue key and summary are required");
            return;
        }

        String updateUrl = jiraUpdateUrl.replace("{issueIdOrKey}", issueKey);
        System.out.println("Updating Jira Issue: " + updateUrl);

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPut request = new HttpPut(updateUrl);
            request.setHeaders(commonUtil.getHeaders());
            request.setEntity(new StringEntity("{ \"fields\": { \"summary\": \"" + newSummary + "\" } }"));

            HttpResponse response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == 204) {
                System.out.println("Updated successfully!");
                completeJob(client, job);
            } else {
                failJob(client, job, "Failed to update Jira, status: " + response.getStatusLine().getStatusCode());
            }
        } catch (Exception e) {
            failJob(client, job, "Exception: " + e.getMessage());
        }
    }

    private void completeJob(JobClient client, ActivatedJob job) {
        try {
            client.newCompleteCommand(job.getKey()).send().join();
        } catch (Exception e) {
            System.out.println("Error completing job: " + e.getMessage());
        }
    }

    private void failJob(JobClient client, ActivatedJob job, String error) {
        try {
            client.newFailCommand(job.getKey()).retries(2).errorMessage(error).send().join();
        } catch (Exception e) {
            System.out.println("Error failing job: " + e.getMessage());
        }
    }
}
